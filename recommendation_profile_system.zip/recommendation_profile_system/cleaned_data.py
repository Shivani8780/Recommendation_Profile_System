import pandas as pd
import numpy as np
import re
from datetime import datetime

# Load dataset
df = pd.read_csv("updated_file.csv")  # Replace with actual file name

### **Step 1: Trim spaces from column names**
df.columns = df.columns.str.strip()

### **Step 2: Trim spaces and clean text fields**
text_columns = ['Name Of Candidate', 'Candidate Current City', 'Cleaned_Education', 'Marriage Status']

for col in text_columns:
    if col in df.columns:
        df[col] = df[col].astype(str)  # Convert to string
        df[col] = df[col].str.strip()  # Remove spaces
        df[col] = df[col].str.lower()  # Convert to lowercase
        df[col] = df[col].apply(lambda x: re.sub(r'[^a-zA-Z0-9\s]', '', x))  # Remove special characters

### **Step 3: Convert 'Date Of Birth' to Age**
if 'Date_Of_Birth' in df.columns:
    df['Date_Of_Birth'] = pd.to_datetime(df['Date_Of_Birth'], errors='coerce')
    df['Age'] = df['Date_Of_Birth'].apply(lambda x: datetime.now().year - x.year if pd.notnull(x) else np.nan)

# Drop rows with missing Age
df = df.dropna(subset=['Age'])



### **Step 5: Remove duplicate rows**
df = df.drop_duplicates()

### **Step 6: Save cleaned data**
df.to_csv("cleaned_data.csv", index=False)
print("✅ Data Cleaning Completed. Saved as 'cleaned_data.csv'")
