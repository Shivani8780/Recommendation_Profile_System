from flask import Flask, render_template, request, send_file
import pandas as pd

app = Flask(__name__)

# Load cleaned dataset
df = pd.read_csv("cleaned_data.csv")

# Generate unique lists for dropdowns
unique_countries = sorted(df['Country'].dropna().unique().tolist()) if 'Country' in df.columns else []
unique_education = sorted(df['Cleaned_Education'].dropna().unique().tolist()) if 'Cleaned_Education' in df.columns else []
unique_jobs = sorted(df['Occupation'].dropna().unique().tolist()) if 'Occupation' in df.columns else []

# Function to filter recommendations
def recommend_profiles(min_age, max_age, gender, country, education, marital_status, min_height, max_height, religion, occupation):
    filtered_df = df[(df['Age'] >= min_age) & (df['Age'] <= max_age)]

    if gender:
        filtered_df = filtered_df[df['Gender'] == gender]

    if country:
        filtered_df = filtered_df[df['Country'].isin(country)]

    if education:
        filtered_df = filtered_df[df['Cleaned_Education'].isin(education)]

    if marital_status:
        filtered_df = filtered_df[df['Marriage Status'] == marital_status]

    if min_height and max_height:
        filtered_df = filtered_df[(df['Height'] >= min_height) & (df['Height'] <= max_height)]

    if religion:
        filtered_df = filtered_df[df['Religion'] == religion]

    if occupation:
        filtered_df = filtered_df[df['Occupation'].isin(occupation)]

    return filtered_df

@app.route('/')
def index():
    return render_template('index.html', countries=unique_countries, education=unique_education, jobs=unique_jobs)

@app.route('/recommend', methods=['POST'])
def recommend():
    min_age = int(request.form['min_age'])
    max_age = int(request.form['max_age'])
    gender = request.form['gender']
    country = request.form.getlist('country')
    education = request.form.getlist('education')
    marital_status = request.form['marital_status']
    min_height = float(request.form['min_height'])
    max_height = float(request.form['max_height'])
    religion = request.form['religion']
    occupation = request.form.getlist('occupation')

    results = recommend_profiles(min_age, max_age, gender, country, education, marital_status, min_height, max_height, religion, occupation)
    
    return render_template('results.html', results=results.to_dict(orient='records'))

@app.route('/download')
def download():
    results = recommend_profiles(25, 30, 'Female', ['India'], ['Bachelors'], 'Single', 5.0, 6.0, 'Hindu', ['Engineer'])
    results.to_csv("recommended_profiles.csv", index=False)
    return send_file("recommended_profiles.csv", as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
